package com.example.aihealthfriend;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;


public class Prediction_Menu_Fragment extends Fragment {


    public Prediction_Menu_Fragment() {
        // Required empty public constructor
    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        container.removeAllViews();

        // Inflate the layout for this fragment
        Intent PredictionmainActivity= new Intent(getActivity(),PredictionMainActivity.class);
        View view= inflater.inflate(R.layout.fragment_prediction_menu, container, false);
        view.findViewById(R.id.predictCard).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(PredictionmainActivity);
            }
        });
        return view;

    }
}