package com.example.aihealthfriend;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


public class ResultsFragment extends Fragment {


    public ResultsFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        container.removeAllViews();
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_results, container, false);
        TextView r =view.findViewById(R.id.predictionResult);
        r.setText(PredictionMainActivity.output);

        return view;
    }
}