package com.example.aihealthfriend;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;


public class PredictionMainActivity extends AppCompatActivity {
    static List<Category> categories;
    public static List<Category> selectedCategories;
    static boolean selectedCategoriesArray[];
    static int currentCategoryIndex = 0;
    private Button nextBtn;
    private Button predBtn;
    private Button prevBtn;
    static int[] selectedDiseases;

    static String output;

    private TextView title;

    public int state;
    private int i;
    private int size;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prediction_main);



        title =  findViewById(R.id.prediction_title);
        prevBtn =  findViewById(R.id.prevButton);
        nextBtn =  findViewById(R.id.nextButton);
        predBtn = findViewById(R.id.predButton);
        state=0;


        categories = initializeCategories();

        selectedCategories=new ArrayList<Category>();

        HashMap<String,Integer> categoriesHeading=new HashMap<>();
        categoriesHeading.put("Head and Face",0);
        categoriesHeading.put("Respiratory System",1);
        categoriesHeading.put("Digestive System",2);
        categoriesHeading.put("Urinary System",3);
        categoriesHeading.put("Skin and Dermatological",4);


        selectedCategories.add(new Category("Please choose the classes to which your symptoms are related",categoriesHeading));

        size=selectedCategories.get(0).getDiseaseIndexMap().size();
        selectedCategoriesArray=new boolean[size] ;

        for (i=0;i<size;i++)
            selectedCategoriesArray[i]=false;

        selectedDiseases = new int[132];
        for (i = 0; i < 132; i++) {
            selectedDiseases[i] = 0;
        }


        title.setVisibility(View.GONE);
        loadFragment(new IntroToPredictFragment());

        prevBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (currentCategoryIndex > 0) {

                    currentCategoryIndex--;
                    loadFragment();
                    updateNavigationButtonsVisibility();
                }
                if(currentCategoryIndex==-1){
                    loadFragment(new IntroToPredictFragment());
                }

                Toast.makeText(PredictionMainActivity.this, " "+currentCategoryIndex, Toast.LENGTH_SHORT).show();
            }
        });

        nextBtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {


                if(state==0){
                    loadFragment();
                    state=1;
                    title.setVisibility(View.VISIBLE);
                }else{
                    if (currentCategoryIndex < selectedCategories.size() - 1) {
                        currentCategoryIndex++;
                        loadFragment();
                        updateNavigationButtonsVisibility();
                    }


                }

                Toast.makeText(PredictionMainActivity.this, " "+currentCategoryIndex, Toast.LENGTH_SHORT).show();
            }
        });

        predBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                title.setText("Prediction Results");
                predict(selectedDiseases);

                loadFragment(new ResultsFragment());
                predBtn.setVisibility(View.GONE);
                currentCategoryIndex++;

                Toast.makeText(PredictionMainActivity.this, " "+currentCategoryIndex, Toast.LENGTH_SHORT).show();

            }
        });
    }

    private List<Category> initializeCategories() {

           List<Category> categories=new ArrayList<>();


            HashMap<String, Integer> headAndFaceMap = new HashMap<>();
            headAndFaceMap.put("Itching", 0);
            headAndFaceMap.put("Skin Rash", 1);
            headAndFaceMap.put("Joint Pain", 6);
            headAndFaceMap.put("Burning Micturition", 12);
            headAndFaceMap.put("Anxiety", 16);
            headAndFaceMap.put("Yellowish Skin", 32);
            headAndFaceMap.put("Acute Liver Failure", 44);
            headAndFaceMap.put("Bloody Stool", 61);
            headAndFaceMap.put("Dizziness", 64);
            headAndFaceMap.put("Obesity", 67);
            headAndFaceMap.put("Swollen Legs", 68);
            headAndFaceMap.put("Enlarged Thyroid", 71);
            headAndFaceMap.put("Brittle Nails", 72);
            headAndFaceMap.put("Foul Smell of Urine", 90);
            headAndFaceMap.put("Irritability", 96);
            headAndFaceMap.put("Rusty Sputum", 108);
            headAndFaceMap.put("Visual Disturbances", 110);
            headAndFaceMap.put("Silver Like Dusting", 126);


            HashMap<String, Integer> respiratorySystemMap = new HashMap<>();
            respiratorySystemMap.put("Continuous Sneezing", 3);
            respiratorySystemMap.put("Cough", 24);
            respiratorySystemMap.put("Sweating", 28);
            respiratorySystemMap.put("Nausea", 34);
            respiratorySystemMap.put("Phlegm", 50);
            respiratorySystemMap.put("Throat Irritation", 51);
            respiratorySystemMap.put("Redness of Eyes", 52);
            respiratorySystemMap.put("Sinus Pressure", 53);
            respiratorySystemMap.put("Runny Nose", 54);
            respiratorySystemMap.put("Congestion", 55);
            respiratorySystemMap.put("Chest Pain", 56);
            respiratorySystemMap.put("Unsteadiness", 86);
            respiratorySystemMap.put("Rusty Sputum", 108);
            respiratorySystemMap.put("Receiving Blood Transfusion", 111);
            respiratorySystemMap.put("Scurring", 124);
            respiratorySystemMap.put("Red Sore Around Nose", 130);


            HashMap<String, Integer> digestiveSystemMap = new HashMap<>();
            digestiveSystemMap.put("Stomach Pain", 7);
            digestiveSystemMap.put("Acidity", 8);
            digestiveSystemMap.put("Muscle Wasting", 10);
            digestiveSystemMap.put("Vomiting", 11);
            digestiveSystemMap.put("Indigestion", 30);
            digestiveSystemMap.put("Loss of Appetite", 35);
            digestiveSystemMap.put("Back Pain", 37);
            digestiveSystemMap.put("Constipation", 38);
            digestiveSystemMap.put("Abdominal Pain", 39);
            digestiveSystemMap.put("Diarrhoea", 40);
            digestiveSystemMap.put("Mild Fever", 41);
            digestiveSystemMap.put("Yellow Urine", 42);
            digestiveSystemMap.put("Yellowing of Eyes", 43);
            digestiveSystemMap.put("Fluid Overload", 45);
            digestiveSystemMap.put("Swelling of Stomach", 46);
            digestiveSystemMap.put("Sinus Pressure", 53);
            digestiveSystemMap.put("Neck Pain", 63);
            digestiveSystemMap.put("Dizziness", 64);
            digestiveSystemMap.put("Muscle Pain", 97);
            digestiveSystemMap.put("Stomach Bleeding", 114);
            digestiveSystemMap.put("Distention of Abdomen", 115);
            digestiveSystemMap.put("Palpitations", 120);


            HashMap<String, Integer> urinarySystemMap = new HashMap<>();
            urinarySystemMap.put("Burning Micturition", 12);
            urinarySystemMap.put("Yellowing of Eyes", 43);
            urinarySystemMap.put("Blurred and Distorted Vision", 49);
            urinarySystemMap.put("Enlarged Thyroid", 71);
            urinarySystemMap.put("Swollen Extremities", 73);
            urinarySystemMap.put("Excessive Hunger", 74);
            urinarySystemMap.put("Foul Smell of Urine", 90);
            urinarySystemMap.put("Continuous Feel of Urine", 91);
            urinarySystemMap.put("Polyuria", 105);

            HashMap<String, Integer> skinAndDermatologicalMap = new HashMap<>();
            skinAndDermatologicalMap.put("Skin Rash", 1);
            skinAndDermatologicalMap.put("Nodal Skin Eruptions", 2);
            skinAndDermatologicalMap.put("Irregular Sugar Level", 23);
            skinAndDermatologicalMap.put("Indigestion", 30);
            skinAndDermatologicalMap.put("Yellowish Skin", 32);
            skinAndDermatologicalMap.put("Irritation in Anus", 62);
            skinAndDermatologicalMap.put("Muscle Weakness", 80);
            skinAndDermatologicalMap.put("Rusty Sputum", 108);
            skinAndDermatologicalMap.put("Lack of Concentration", 109);
            skinAndDermatologicalMap.put("Blackheads", 123);
            skinAndDermatologicalMap.put("Scurring", 124);
            skinAndDermatologicalMap.put("Skin Peeling", 125);
            skinAndDermatologicalMap.put("Silver Like Dusting", 126);
            skinAndDermatologicalMap.put("Small Dents in Nails", 127);
            skinAndDermatologicalMap.put("Inflammatory Nails", 128);
            skinAndDermatologicalMap.put("Blister", 129);
            skinAndDermatologicalMap.put("Red Sore Around Nose", 130);
            skinAndDermatologicalMap.put("Yellow Crust Ooze", 131);


            categories.add(new Category("Head and Face",headAndFaceMap));
            categories.add(new Category("Respiratory System",respiratorySystemMap));
            categories.add(new Category("Digestive System",digestiveSystemMap));
            categories.add(new Category("Urinary System",urinarySystemMap));
            categories.add(new Category("Skin and Dermatological",skinAndDermatologicalMap));


            return categories;
    }


    public void loadFragment() {
        title.setText(selectedCategories.get(currentCategoryIndex).getTitle());
        Fragment fragment = PredictionListAndInfoFragment.newInstance(selectedCategories.get(currentCategoryIndex));
        getSupportFragmentManager().beginTransaction().replace(R.id.Symptom_list_container, fragment).commit();
    }

    public void loadFragment(Fragment f){
        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        ft.replace(R.id.Symptom_list_container, f);
        ft.commit();
    }


    public void updateNavigationButtonsVisibility() {
        prevBtn.setVisibility(currentCategoryIndex == 0 ? View.GONE : View.VISIBLE);
        nextBtn.setVisibility(currentCategoryIndex == selectedCategories.size() -1 ?View.GONE : View.VISIBLE);
        predBtn.setVisibility(currentCategoryIndex == selectedCategories.size() -1 ? View.VISIBLE : View.GONE);
    }


    void predict(int[] input){
        // Define your request URL
        String url = "http://192.168.42.103:8080/predict"; // Replace with your actual URL

        // Create a JSON object to send as the request body
        JSONObject jsonRequest = new JSONObject();

        try {


            JSONArray jsonarray=new JSONArray();
            for(int i:input){
                jsonarray.put(i);
            }

            jsonRequest.put("features", jsonarray); // Add your input values here
        } catch (JSONException e) {
            e.printStackTrace();
        }

        // Create an OkHttpClient
        OkHttpClient client = new OkHttpClient();

        // Create a request body with the JSON data
        RequestBody requestBody = RequestBody.create(
                MediaType.parse("application/json; charset=utf-8"),
                jsonRequest.toString()
        );

        // Create an HTTP POST request
        Request request = new Request.Builder()
                .url(url)
                .post(requestBody)
                .build();

        // Make the HTTP request asynchronously
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                output="Some Error";
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    // Handle the response as needed
                    final String jsonResponse = response.body().string();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                // Parse and process the response JSON
                                JSONObject responseObject = new JSONObject(jsonResponse);
                                String Output =  responseObject.getString("prediction");
                                // Handle the response here
                                output=Output;

                            } catch (JSONException e) {
                                output="Error last";
                            }
                        }
                    });
                }
                response.close();
            }
        });
    }
}