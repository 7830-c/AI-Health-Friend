package com.example.aihealthfriend;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;


public class MyListAdapter extends ArrayAdapter<String> {
    private final String[] arr;

    public interface OnSymptomClickListener {
        void onSymptomClick(int i,String symptom);
    }

    private OnSymptomClickListener onSymptomClickListener;

    public interface OnCategoryClickListener {
        void onCategoryClick(int i);
    }

    private OnCategoryClickListener onCategoryClickListener;



    public MyListAdapter(Context context, int resource, String[] arr) {
        super(context, resource, arr);
        this.arr = arr;
    }

    @Override
    public String getItem(int position) {
        return arr[position];
    }

    public void setOnSymptomClickListener(OnSymptomClickListener listener) {
        onSymptomClickListener = listener;
    }
    public void setOnCategoryClickListener(OnCategoryClickListener listener) {
        onCategoryClickListener = listener;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        convertView = LayoutInflater.from(getContext()).inflate(R.layout.custom_list_item_design, parent, false);
        TextView t = convertView.findViewById(R.id.listItem);
        t.setText(getItem(position));
        int index=0;
        if(PredictionMainActivity.currentCategoryIndex!=0){
            if(PredictionMainActivity.selectedCategories.get(PredictionMainActivity.currentCategoryIndex).getDiseaseIndexMap().get(getItem(position))!=null){
                index= PredictionMainActivity.selectedCategories.get(PredictionMainActivity.currentCategoryIndex).getDiseaseIndexMap().get(getItem(position));
                if(PredictionMainActivity.selectedDiseases[index]==1){
                    convertView.setBackgroundResource(R.drawable.list_item_background_after);

                }
            }
        }else{
            if(PredictionMainActivity.selectedCategoriesArray[position]!=false){

                    convertView.setBackgroundResource(R.drawable.list_item_background_after);

                }
       }


        convertView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(PredictionMainActivity.currentCategoryIndex==0)
                {
                    categoryClick(position);
                }
                else{
                    SymptomClick(position,getItem(position));
                }
            }
        });
        return convertView;


    }

    public void SymptomClick(int position,String symptom) {
        if (onSymptomClickListener != null) {
            onSymptomClickListener.onSymptomClick(position,symptom);
        }
    }

    public void categoryClick(int position) {
        if (onCategoryClickListener != null) {
            onCategoryClickListener.onCategoryClick(position);
        }
    }
}

