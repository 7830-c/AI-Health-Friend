package com.example.aihealthfriend;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;


public class Profile_Menu_Fragment extends Fragment {


    public Profile_Menu_Fragment() {
        // Required empty public constructor
    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        container.removeAllViews();

        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_profile_menu, container, false);
    }
}