package com.example.aihealthfriend;

import java.io.Serializable;
import java.util.HashMap;

public class Category implements Serializable {
    private String title;
    private HashMap<String, Integer> diseaseIndexMap;

    public Category(String title, HashMap<String, Integer> diseaseIndexMap) {
        this.title = title;
        this.diseaseIndexMap = diseaseIndexMap;
    }

    public String getTitle() {
        return title;
    }

    public HashMap<String, Integer> getDiseaseIndexMap() {
        return diseaseIndexMap;
    }
}
