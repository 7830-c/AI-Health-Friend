package com.example.aihealthfriend;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListAdapter;
import android.widget.ListView;
import androidx.fragment.app.Fragment;
import com.example.aihealthfriend.MyListAdapter;


public class PredictionListAndInfoFragment extends Fragment implements MyListAdapter.OnSymptomClickListener,MyListAdapter.OnCategoryClickListener {
    private Category currentCategory;
    private ListView listView;


    public static PredictionListAndInfoFragment newInstance(Category category) {
        PredictionListAndInfoFragment fragment = new PredictionListAndInfoFragment();
        Bundle args = new Bundle();
        args.putSerializable("category", category);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            this.currentCategory = (Category) getArguments().getSerializable("category");

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        container.removeAllViews();
        View view = inflater.inflate(R.layout.fragment_prediction_list_and_info, container, false);

        listView = view.findViewById(R.id.symptom_list);

        MyListAdapter listadp = new MyListAdapter(getContext(), R.layout.custom_list_item_design, currentCategory.getDiseaseIndexMap().keySet().toArray(new String[0]));

        if (PredictionMainActivity.currentCategoryIndex == 0) {
            listadp.setOnCategoryClickListener(this);
            listadp.setOnSymptomClickListener(null);
        } else {
            listadp.setOnCategoryClickListener(null);
            listadp.setOnSymptomClickListener(this);
        }

        listView.setAdapter(listadp); //before change

        return view;
    }

    @Override
    public void onSymptomClick(int position, String Symptom) {
        int index = currentCategory.getDiseaseIndexMap().get(Symptom);
        if (PredictionMainActivity.selectedDiseases[index] == 0) {
            listView.getChildAt(position).setBackgroundResource(R.drawable.list_item_background_after);
            PredictionMainActivity.selectedDiseases[index] = 1;
        } else {
            listView.getChildAt(position).setBackgroundResource(R.drawable.list_item_background_initial);
            PredictionMainActivity.selectedDiseases[index] = 0;
        }

    }

    @Override
    public void onCategoryClick(int i) {
        // if (PredictionMainActivity.selectedCategoriesArray[i] == false) {
        // listView.getChildAt(i).setBackgroundResource(R.drawable.list_item_background_after);
        //PredictionMainActivity.selectedCategoriesArray[i] = true;
        //PredictionMainActivity.selectedCategories.add(PredictionMainActivity.categories.get(i));

        Category cat = PredictionMainActivity.categories.get(i);
        //if (!PredictionMainActivity.selectedCategories.contains(cat)) {
          //  PredictionMainActivity.selectedCategories.add(cat);
//            } else {
//                listView.getChildAt(i).setBackgroundResource(R.drawable.list_item_background_initial);
//                PredictionMainActivity.selectedCategoriesArray[i] = false;
//               // PredictionMainActivity.selectedCategories.remove(i);
//
//            }

            if (PredictionMainActivity.selectedCategoriesArray[i] == false) {
                listView.getChildAt(i).setBackgroundResource(R.drawable.list_item_background_after);
                if (!PredictionMainActivity.selectedCategories.contains(cat)) {
                    PredictionMainActivity.selectedCategories.add(cat);
                    PredictionMainActivity.selectedCategoriesArray[i] = true;
                } else {
                    listView.getChildAt(i).setBackgroundResource(R.drawable.list_item_background_initial);
                    PredictionMainActivity.selectedCategoriesArray[i] = false;
                    PredictionMainActivity.selectedCategories.remove(cat);
                }


            }
        }
    }

