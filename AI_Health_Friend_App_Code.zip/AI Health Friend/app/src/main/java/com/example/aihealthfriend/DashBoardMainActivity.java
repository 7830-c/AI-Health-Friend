package com.example.aihealthfriend;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.MenuItem;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;

public class DashBoardMainActivity extends AppCompatActivity {
    BottomNavigationView bnView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dash_board_main);

        bnView=findViewById(R.id.bnView);

        bnView.setItemIconSize(80);



        bnView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id=item.getItemId();

                if(id==R.id.nav_profile){
                    loadFrag(new Profile_Menu_Fragment(),true);
                }else if(id==R.id.nav_ai){
                    loadFrag(new Prediction_Menu_Fragment(),false);
                }else if(id==R.id.nav_doctor){
                    loadFrag(new Doctor_Menu_Fragment(),false);
                }

                return true; //indicate item selected
        }
        });

        bnView.setSelectedItemId(R.id.nav_ai);


    }


    //for spacing fragment in our frame layout of activity
    public void loadFrag(Fragment fragment,boolean flag){
        FragmentManager fm=getSupportFragmentManager();
        FragmentTransaction ft=fm.beginTransaction();


        if(flag){
            ft.add(R.id.container,fragment); //put fragment on a fragment layout that has id container.For first time
        }else{
            ft.replace(R.id.container,fragment);//We will replace current fragment by another
        }

        ft.addToBackStack(null);//Main tain the order n which called so return to previous fragmnet

        ft.commit(); //Apply all above steps

    }
}